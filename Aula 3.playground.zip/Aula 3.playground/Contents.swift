//var name: String? = "Paulo"
//name = nil

//if name != nil {
//    let nameTwo: String = name!
//}

// 1 - Default Value
//let nameResult: String = name ?? "Maria"
//print(nameResult)

// 2 - If let

//if let name = name {
//    print(name)
//}

// 3 - Guard let

//@MainActor func some() {
//    guard let name else{
//        print("Digite seu nome")
//        return
//    }
//    print(name)
//}
//some()

//Exercicio

let name: String? = "Paulo"  //String
let number: Double? = 20.3 //Double
let age: String = "20" //Int
let gender: Int? = 0 //Boll

//Name transformando em string
if let name {
    let namResult: String = name
}

// number transformando em double
@MainActor func some() {
    guard let number else{
        print("digite um double")
        return
    }
    print(number)
}
