let name: String? = "Paulo" //String
let number: Double? = 20.3 // Double
let numberTwo: String? = "20.5" //Float
let age: String = "20" //int
let gender: Int? = 0 //Boll

if let name {
    let nameResult: String = name
}
