import UIKit

// soma entre 3 string

var A: String
A = "123"

var B: String
B = "456"

var C: String
C = "789"

A + B + C
// juntar 3 string nesse caso esta "concatenando"

// para somar o valor do string precisa transformar em número e forçar com "!"
var D = Int (A)
var E = Int (B)
var F = Int (C)

var resultado = D! +  E! + F!
