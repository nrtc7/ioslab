let nome: String = "Pietro"
var ano: Float = 1997
var idade: String = "26"
var data: Double = 14
var classificação: Character = "1"
var telefone: String = "11948224450"

//variaveis professor

let name: String = "Pietro"
let neighboarfhood: String = "Vila Sonia"
let maritalStatus: String = "Casado"
let age: String = "30"
let weight: Float = 70.2
let gender: Character = "F"

// converter variável (cast)

let weightToString = String(age)
let ageToInt = Int(age)

let numberOne: Int? = nil
let numberTwo: Int? = 20

// nil = nulo

//let result = numberOne! + numberTwo!

//Como é um valor nulo não tem como soma com um inteiro
//Opção de solução é colocar uma condição porém não se aplica no dia a dia

if numberOne != nil && numberTwo != nil { 
    let result = numberOne! + numberTwo!
    print (result)
}

// if - else

let name1: String = "Paulo"
//
//if name1 == "Paulo" {
//    print("Seu nome é Paulo")
//} else {
//    if name1 == "João" {
//        print( "Seu nome é João")
//    } else {
//        if name1 == "Maurício" {
//            print ("Seu nome é Maurício")
//        } else {
//            print ("Seu nome NÃO é nenhum cadastrado")
//        }
//    }
//}

// Outra possibilidade para resumir o codigo

//if name1 == "Paulo" {
//if name1 == "Paulo" {
//    print("Seu nome é Paulo")
//} else if name1 == "João" {
//        print( "Seu nome é João")
//    } else if name1 == "Maurício" {
//            print ("Seu nome é Maurício")
//        } else {
//            print ("Seu nome NÃO é nenhum cadastrado")
//        }
    
// Outra possibilidade para resumir ainda mais é utilizar o operador (||)

//if name1 == "Paulo" || name1 == "João" || name1 == "Maurício" {
//    print("Seu nome é \(name1)")
//} else {
//    print ("Seu nome NÃO é nenhum cadastrado")
//}

// nome + sobrenome

let name2: String = "Mauricio"
let lastname: String = "Soares"

//if name2 == "Paulo" && lastname == "Soares" {
//    print("Voce está na lista de convidados")
//} else {
//    print("Você NÃO está na lista")
//}

// Fazer a logica a cima com 3 nomes
// Paulo Soares
// Roberto Martins
// Andre Jose

if (name2 == "Paulo" && lastname == "Soares") ||
   (name2 == "Roberto" && lastname == "Martins") ||
   (name2 == "Andre" && lastname == "Jose") {
print ("Voce está na lista de convidados")
} else {
    print ("Voce Não está na lista")
}

//Exercicio

let number1: Float = 4.3
let number2: Float = 2.3

let result = number1 + number2

if result < 3 {
    print("Voce ficou de recuperação")
} else if result > 3 && result < 5 {
    print ("Voce está na media")
} else if result > 5 {
    print ("Voce passou")
}
